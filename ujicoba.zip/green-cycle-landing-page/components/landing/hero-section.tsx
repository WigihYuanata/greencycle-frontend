"use client"

import { ArrowRight, Play, Sparkles, Leaf, Recycle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HeroSectionProps {
  onStartClick: () => void
  onHowItWorksClick: () => void
}

export function HeroSection({ onStartClick, onHowItWorksClick }: HeroSectionProps) {
  return (
    <section id="beranda" className="relative min-h-screen pt-20 md:pt-24 overflow-hidden">
      {/* Background gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 via-background to-background" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4" />
      
      {/* Floating elements */}
      <div className="absolute top-32 left-8 md:left-16 w-12 h-12 md:w-16 md:h-16 bg-accent/20 rounded-2xl rotate-12 animate-float hidden sm:block" />
      <div className="absolute top-48 right-12 md:right-24 w-8 h-8 md:w-10 md:h-10 bg-primary/20 rounded-xl -rotate-12 animate-float" style={{ animationDelay: '2s' }} />
      <div className="absolute bottom-32 left-1/4 w-6 h-6 bg-accent/30 rounded-lg rotate-45 animate-float hidden md:block" style={{ animationDelay: '1s' }} />
      
      <div className="relative container mx-auto px-4 py-8 md:py-16">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Content */}
          <div className="order-2 lg:order-1 text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-6 animate-fade-in">
              <Sparkles className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-muted-foreground">
                Bersama, kecil hari ini, besar untuk masa depan.
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 animate-slide-up text-balance">
              <span className="text-foreground">Ubah botol plastik</span>
              <br />
              <span className="text-foreground">jadi langkah nyata</span>
              <br />
              <span className="gradient-text">untuk bumi kita.</span>
              <span className="inline-block ml-2">
                <Leaf className="w-8 h-8 md:w-10 md:h-10 text-accent inline animate-pulse-soft" />
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 mb-8 animate-slide-up text-pretty leading-relaxed" style={{ animationDelay: '0.1s' }}>
              GreenCycle mengajak seluruh mahasiswa UPN &ldquo;Veteran&rdquo; Jawa Timur untuk bersama-sama daur ulang, kumpulkan poin, dan ciptakan dampak besar bagi lingkungan kampus.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Button 
                size="lg"
                onClick={onStartClick}
                className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl shadow-primary/25 hover:shadow-primary/35 transition-all text-base px-8 py-6 rounded-2xl group"
              >
                <Recycle className="w-5 h-5 mr-2 group-hover:rotate-180 transition-transform duration-500" />
                Mulai Daur Ulang
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                size="lg"
                variant="outline"
                onClick={onHowItWorksClick}
                className="border-2 border-border hover:border-primary/50 hover:bg-secondary/50 text-foreground text-base px-8 py-6 rounded-2xl group"
              >
                <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                Lihat Cara Kerja
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex items-center justify-center lg:justify-start gap-6 mt-10 pt-8 border-t border-border/50 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div 
                      key={i} 
                      className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/80 to-accent/80 border-2 border-card flex items-center justify-center"
                    >
                      <span className="text-xs font-medium text-primary-foreground">{i}</span>
                    </div>
                  ))}
                </div>
                <span className="text-sm text-muted-foreground ml-2">2.350+ kontributor aktif</span>
              </div>
            </div>
          </div>

          {/* Hero Visual */}
          <div className="order-1 lg:order-2 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main visual container */}
              <div className="relative aspect-square md:aspect-[4/3] rounded-3xl overflow-hidden">
                {/* Gradient background placeholder for hero image */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/10 to-secondary" />
                
                {/* Smart Bin illustration */}
                <div className="absolute inset-0 flex items-center justify-center p-8">
                  <div className="relative w-full max-w-xs">
                    {/* Machine body */}
                    <div className="bg-gradient-to-b from-primary to-primary/80 rounded-3xl p-6 shadow-2xl shadow-primary/20">
                      <div className="bg-card/95 rounded-2xl p-4 mb-4">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground mb-1">UPNVJT</p>
                          <div className="flex items-center justify-center gap-2 mb-2">
                            <Leaf className="w-5 h-5 text-primary" />
                            <span className="text-lg font-bold text-primary">GreenCycle</span>
                          </div>
                          <div className="bg-secondary rounded-xl p-3">
                            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">SATU BOTOL</p>
                            <p className="text-xs font-semibold text-foreground">Dampak Besar!</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Bottle slot */}
                      <div className="bg-foreground/20 rounded-2xl h-16 flex items-center justify-center mb-4 border-2 border-dashed border-foreground/30">
                        <p className="text-sm font-medium text-primary-foreground/80">Masukkan Botol</p>
                      </div>
                      
                      {/* Stats display */}
                      <div className="bg-card rounded-xl p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Botol didaur ulang</p>
                        <p className="text-2xl font-bold text-primary">3.250+</p>
                      </div>
                    </div>
                    
                    {/* Collection bin */}
                    <div className="absolute -bottom-4 -right-4 w-24 h-32 bg-gradient-to-t from-primary/60 to-primary/40 rounded-xl shadow-lg" />
                    
                    {/* Floating bottle */}
                    <div className="absolute -top-6 -right-6 w-16 h-24 bg-accent/30 rounded-lg rotate-12 animate-float flex items-center justify-center">
                      <span className="text-2xl">🍾</span>
                    </div>
                  </div>
                </div>
                
                {/* Decorative elements */}
                <div className="absolute top-4 left-4 px-3 py-1.5 bg-card/90 backdrop-blur rounded-full shadow-lg">
                  <span className="text-xs font-medium text-primary">🌿 Eco-Friendly</span>
                </div>
                <div className="absolute bottom-4 right-4 px-3 py-1.5 bg-card/90 backdrop-blur rounded-full shadow-lg">
                  <span className="text-xs font-medium text-foreground">+20 Poin</span>
                </div>
              </div>

              {/* Floating stat cards */}
              <div className="absolute -bottom-4 -left-4 md:-left-8 bg-card rounded-2xl shadow-xl p-4 border border-border/50 animate-float" style={{ animationDelay: '0.5s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                    <Recycle className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Botol Didaur Ulang</p>
                    <p className="text-lg font-bold text-foreground">3.250+</p>
                  </div>
                </div>
              </div>

              <div className="absolute -top-4 -right-4 md:-right-8 bg-card rounded-2xl shadow-xl p-4 border border-border/50 animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Leaf className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Kontributor Aktif</p>
                    <p className="text-lg font-bold text-foreground">2.350+</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path 
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" 
            fill="currentColor"
            className="text-card"
          />
        </svg>
      </div>
    </section>
  )
}
