"use client"

import { useState } from "react"
import { Menu, Leaf, User, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

const navItems = [
  { label: "Beranda", href: "#beranda" },
  { label: "Tentang Kami", href: "#tentang" },
  { label: "Cara Kerja", href: "#cara-kerja" },
  { label: "Dampak", href: "#dampak" },
  { label: "Poin & Reward", href: "#reward" },
  { label: "FAQ", href: "#faq" },
]

interface HeaderProps {
  onLoginClick: () => void
  onRegisterClick: () => void
}

export function Header({ onLoginClick, onRegisterClick }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false)

  const closeSheet = () => setIsOpen(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#beranda" className="flex items-center gap-2 group">
            <div className="relative">
              <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/30 transition-shadow">
                <Leaf className="w-5 h-5 md:w-6 md:h-6 text-primary-foreground" />
              </div>
              <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-accent rounded-full animate-pulse-soft" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg md:text-xl font-bold text-foreground tracking-tight">GreenCycle</span>
              <span className="text-[10px] md:text-xs text-muted-foreground -mt-1 hidden sm:block">Teaching Industry Project UPN Veteran Jawa Timur</span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-secondary/50"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onLoginClick}
              className="text-muted-foreground hover:text-foreground"
            >
              <User className="w-4 h-4 mr-2" />
              Masuk
            </Button>
            <Button 
              size="sm"
              onClick={onRegisterClick}
              className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-primary/35 transition-all"
            >
              <Leaf className="w-4 h-4 mr-2" />
              Daftar Sekarang
            </Button>
          </div>

          {/* Mobile Menu */}
          <div className="flex md:hidden items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onLoginClick}
              className="text-muted-foreground"
            >
              <LogIn className="w-5 h-5" />
            </Button>
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-foreground">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 p-0">
                <div className="flex flex-col h-full pt-14">
                  <div className="flex items-center gap-2 px-4 pb-4 border-b border-border">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                      <Leaf className="w-4 h-4 text-primary-foreground" />
                    </div>
                    <span className="font-bold text-foreground">GreenCycle</span>
                  </div>
                  <nav className="flex-1 p-4">
                    <div className="space-y-1">
                      {navItems.map((item) => (
                        <a
                          key={item.href}
                          href={item.href}
                          onClick={closeSheet}
                          className="flex items-center px-4 py-3 text-base font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 rounded-xl transition-colors"
                        >
                          {item.label}
                        </a>
                      ))}
                    </div>
                  </nav>
                  <div className="p-4 border-t border-border space-y-3">
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => { closeSheet(); onLoginClick(); }}
                    >
                      Masuk
                    </Button>
                    <Button 
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={() => { closeSheet(); onRegisterClick(); }}
                    >
                      <Leaf className="w-4 h-4 mr-2" />
                      Daftar Sekarang
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
