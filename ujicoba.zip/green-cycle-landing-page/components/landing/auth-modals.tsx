"use client"

import { useState } from "react"
import { Eye, EyeOff, Leaf, Mail, User, Building2, Lock, ArrowRight, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const faculties = [
  "Fakultas Ekonomi dan Bisnis",
  "Fakultas Teknik",
  "Fakultas Ilmu Sosial dan Ilmu Politik",
  "Fakultas Pertanian",
  "Fakultas Hukum",
  "Fakultas Arsitektur dan Desain",
  "Fakultas Ilmu Komputer",
]

type AuthView = "login" | "register" | "forgot" | "reset"

interface AuthModalsProps {
  isOpen: boolean
  onClose: () => void
  initialView?: AuthView
}

export function AuthModals({ isOpen, onClose, initialView = "login" }: AuthModalsProps) {
  const [view, setView] = useState<AuthView>(initialView)
  const [isLoading, setIsLoading] = useState(false)
  const [showPin, setShowPin] = useState(false)
  
  // Form states
  const [loginForm, setLoginForm] = useState({ npm: "", pin: "" })
  const [registerForm, setRegisterForm] = useState({ npm: "", name: "", faculty: "", email: "", pin: "", confirmPin: "" })
  const [forgotForm, setForgotForm] = useState({ npm: "" })
  const [resetForm, setResetForm] = useState({ npm: "", kode_verifikasi: "", new_pin: "", confirm_pin: "" })
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsLoading(false)
    // In real implementation, this would call the actual backend API
    if (view === "forgot") {
      setView("reset")
    } else {
      onClose()
    }
  }

  const resetForms = () => {
    setLoginForm({ npm: "", pin: "" })
    setRegisterForm({ npm: "", name: "", faculty: "", email: "", pin: "", confirmPin: "" })
    setForgotForm({ npm: "" })
    setResetForm({ npm: "", kode_verifikasi: "", new_pin: "", confirm_pin: "" })
  }

  const handleViewChange = (newView: AuthView) => {
    setView(newView)
    setShowPin(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) { onClose(); resetForms(); } }}>
      <DialogContent showCloseButton={false} className="sm:max-w-md p-0 overflow-hidden border-0 rounded-3xl">
        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-primary to-primary/80 p-6 pb-8">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
          <DialogHeader className="relative">
            <div className="flex items-center justify-center mb-4">
              <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center">
                <Leaf className="w-7 h-7 text-white" />
              </div>
            </div>
            <DialogTitle className="text-center text-white text-xl">
              {view === "login" && "Masuk ke GreenCycle"}
              {view === "register" && "Daftar GreenCycle"}
              {view === "forgot" && "Lupa PIN"}
              {view === "reset" && "Reset PIN"}
            </DialogTitle>
            <p className="text-center text-white/80 text-sm mt-1">
              {view === "login" && "Selamat datang kembali, kontributor!"}
              {view === "register" && "Bergabung dengan gerakan hijau kampus"}
              {view === "forgot" && "Masukkan NPM untuk reset PIN"}
              {view === "reset" && "Masukkan kode verifikasi dari email"}
            </p>
          </DialogHeader>
        </div>

        {/* Form content */}
        <div className="p-6 bg-card">
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Login Form */}
            {view === "login" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="npm" className="text-foreground text-sm">NPM</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="npm"
                      placeholder="Masukkan NPM"
                      value={loginForm.npm}
                      onChange={(e) => setLoginForm({ ...loginForm, npm: e.target.value })}
                      className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pin" className="text-foreground text-sm">PIN</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="pin"
                      type={showPin ? "text" : "password"}
                      placeholder="Masukkan PIN"
                      value={loginForm.pin}
                      onChange={(e) => setLoginForm({ ...loginForm, pin: e.target.value })}
                      className="pl-10 pr-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => handleViewChange("forgot")}
                    className="text-sm text-primary hover:underline"
                  >
                    Lupa PIN?
                  </button>
                </div>
              </>
            )}

            {/* Register Form */}
            {view === "register" && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reg-npm" className="text-foreground text-sm">NPM</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="reg-npm"
                        placeholder="NPM"
                        value={registerForm.npm}
                        onChange={(e) => setRegisterForm({ ...registerForm, npm: e.target.value })}
                        className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reg-name" className="text-foreground text-sm">Nama Lengkap</Label>
                    <Input
                      id="reg-name"
                      placeholder="Nama"
                      value={registerForm.name}
                      onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                      className="rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-faculty" className="text-foreground text-sm">Fakultas</Label>
                  <Select
                    value={registerForm.faculty}
                    onValueChange={(value) => setRegisterForm({ ...registerForm, faculty: value })}
                  >
                    <SelectTrigger className="rounded-xl border-border/50 bg-secondary/30">
                      <Building2 className="w-4 h-4 text-muted-foreground mr-2" />
                      <SelectValue placeholder="Pilih Fakultas" />
                    </SelectTrigger>
                    <SelectContent>
                      {faculties.map((faculty) => (
                        <SelectItem key={faculty} value={faculty}>{faculty}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-email" className="text-foreground text-sm">Email Student</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder="npm@student.upnjatim.ac.id"
                      value={registerForm.email}
                      onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                      className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                      required
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground">Format: npm@student.upnjatim.ac.id</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reg-pin" className="text-foreground text-sm">PIN</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="reg-pin"
                        type={showPin ? "text" : "password"}
                        placeholder="PIN"
                        value={registerForm.pin}
                        onChange={(e) => setRegisterForm({ ...registerForm, pin: e.target.value })}
                        className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reg-confirm" className="text-foreground text-sm">Konfirmasi PIN</Label>
                    <div className="relative">
                      <Input
                        id="reg-confirm"
                        type={showPin ? "text" : "password"}
                        placeholder="Konfirmasi"
                        value={registerForm.confirmPin}
                        onChange={(e) => setRegisterForm({ ...registerForm, confirmPin: e.target.value })}
                        className="rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPin(!showPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Forgot PIN Form */}
            {view === "forgot" && (
              <div className="space-y-2">
                <Label htmlFor="forgot-npm" className="text-foreground text-sm">NPM</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="forgot-npm"
                    placeholder="Masukkan NPM terdaftar"
                    value={forgotForm.npm}
                    onChange={(e) => setForgotForm({ ...forgotForm, npm: e.target.value })}
                    className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                    required
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Kode verifikasi akan dikirim ke email yang terdaftar dengan NPM ini.
                </p>
              </div>
            )}

            {/* Reset PIN Form */}
            {view === "reset" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="reset-npm" className="text-foreground text-sm">NPM</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="reset-npm"
                      placeholder="Masukkan NPM"
                      value={resetForm.npm}
                      onChange={(e) => setResetForm({ ...resetForm, npm: e.target.value })}
                      className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reset-code" className="text-foreground text-sm">Kode Verifikasi</Label>
                  <Input
                    id="reset-code"
                    placeholder="Masukkan 6 digit kode"
                    value={resetForm.kode_verifikasi}
                    onChange={(e) => setResetForm({ ...resetForm, kode_verifikasi: e.target.value })}
                    className="rounded-xl border-border/50 bg-secondary/30 focus:bg-card text-center text-lg tracking-widest"
                    maxLength={6}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="reset-pin" className="text-foreground text-sm">PIN Baru</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="reset-pin"
                        type={showPin ? "text" : "password"}
                        placeholder="PIN Baru"
                        value={resetForm.new_pin}
                        onChange={(e) => setResetForm({ ...resetForm, new_pin: e.target.value })}
                        className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reset-confirm" className="text-foreground text-sm">Konfirmasi</Label>
                    <div className="relative">
                      <Input
                        id="reset-confirm"
                        type={showPin ? "text" : "password"}
                        placeholder="Konfirmasi"
                        value={resetForm.confirm_pin}
                        onChange={(e) => setResetForm({ ...resetForm, confirm_pin: e.target.value })}
                        className="rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPin(!showPin)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Submit button */}
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl py-6 text-base shadow-lg shadow-primary/25"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Memproses...
                </>
              ) : (
                <>
                  {view === "login" && "Masuk"}
                  {view === "register" && "Daftar Sekarang"}
                  {view === "forgot" && "Kirim Kode Verifikasi"}
                  {view === "reset" && "Reset PIN"}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </form>

          {/* Footer links */}
          <div className="mt-6 pt-6 border-t border-border/50 text-center">
            {view === "login" && (
              <p className="text-sm text-muted-foreground">
                Belum punya akun?{" "}
                <button
                  onClick={() => handleViewChange("register")}
                  className="text-primary font-medium hover:underline"
                >
                  Daftar sekarang
                </button>
              </p>
            )}
            {view === "register" && (
              <p className="text-sm text-muted-foreground">
                Sudah punya akun?{" "}
                <button
                  onClick={() => handleViewChange("login")}
                  className="text-primary font-medium hover:underline"
                >
                  Masuk
                </button>
              </p>
            )}
            {(view === "forgot" || view === "reset") && (
              <p className="text-sm text-muted-foreground">
                Ingat PIN kamu?{" "}
                <button
                  onClick={() => handleViewChange("login")}
                  className="text-primary font-medium hover:underline"
                >
                  Kembali ke login
                </button>
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
