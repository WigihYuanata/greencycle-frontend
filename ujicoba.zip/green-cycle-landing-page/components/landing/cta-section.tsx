"use client"

import { ArrowRight, Leaf, Check, Sparkles, Recycle } from "lucide-react"
import { Button } from "@/components/ui/button"

const features = [
  { text: "Mudah Dilakukan", description: "Proses cepat & praktis" },
  { text: "Dampak Nyata", description: "Perubahan besar untuk bumi" },
  { text: "Reward Menarik", description: "Poin bisa ditukar hadiah" },
]

interface CTASectionProps {
  onStartClick: () => void
  onRewardsClick: () => void
}

export function CTASection({ onStartClick, onRewardsClick }: CTASectionProps) {
  return (
    <section className="relative py-16 md:py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-accent" />
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-white/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-[300px] h-[300px] bg-white/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      <div className="absolute top-1/4 right-1/4 w-4 h-4 bg-white/20 rounded-full animate-pulse-soft" />
      <div className="absolute bottom-1/3 left-1/3 w-3 h-3 bg-white/30 rounded-full animate-pulse-soft" style={{ animationDelay: '1s' }} />
      
      {/* Floating icons */}
      <div className="absolute top-16 left-8 md:left-16 opacity-20">
        <Leaf className="w-12 h-12 text-white rotate-12" />
      </div>
      <div className="absolute bottom-16 right-8 md:right-16 opacity-20">
        <Recycle className="w-16 h-16 text-white -rotate-12" />
      </div>
      
      <div className="relative container mx-auto px-4 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur border border-white/20 mb-6">
          <Sparkles className="w-4 h-4 text-white" />
          <span className="text-sm font-medium text-white/90">Mulai Sekarang</span>
        </div>
        
        {/* Headline */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 text-balance max-w-3xl mx-auto">
          Bersama, kita wujudkan kampus yang lebih hijau.
        </h2>
        
        {/* Subtitle */}
        <p className="text-base md:text-lg text-white/80 max-w-xl mx-auto mb-8 text-pretty">
          Satu botol darimu, sejuta perubahan untuk bumi kita.
        </p>
        
        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10">
          <Button 
            size="lg"
            onClick={onStartClick}
            className="bg-white hover:bg-white/95 text-primary shadow-xl shadow-black/10 hover:shadow-black/20 transition-all text-base px-8 py-6 rounded-2xl group"
          >
            <Recycle className="w-5 h-5 mr-2 group-hover:rotate-180 transition-transform duration-500" />
            Mulai Daur Ulang Sekarang
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            size="lg"
            variant="outline"
            onClick={onRewardsClick}
            className="border-2 border-white/30 bg-white/10 hover:bg-white/20 text-white text-base px-8 py-6 rounded-2xl"
          >
            Lihat Poin & Reward
          </Button>
        </div>
        
        {/* Features */}
        <div className="flex flex-wrap justify-center gap-4 md:gap-8">
          {features.map((feature) => (
            <div key={feature.text} className="flex items-center gap-3 bg-white/10 backdrop-blur rounded-xl px-4 py-3">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                <Check className="w-4 h-4 text-white" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-white text-sm">{feature.text}</p>
                <p className="text-xs text-white/70">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
