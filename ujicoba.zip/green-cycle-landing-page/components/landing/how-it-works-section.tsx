"use client"

import { CreditCard, Inbox, Cpu, Coins, History, Gift, ArrowRight, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"

const steps = [
  {
    number: 1,
    icon: CreditCard,
    title: "Tap Kartu",
    description: "Tempelkan kartu mahasiswa pada Smart BIN untuk memulai.",
  },
  {
    number: 2,
    icon: Inbox,
    title: "Masukkan Botol",
    description: "Masukkan botol plastik ke dalam lubang mesin.",
  },
  {
    number: 3,
    icon: Cpu,
    title: "Sistem Menghitung",
    description: "Mesin akan menghitung jenis dan ukuran botol secara otomatis.",
  },
  {
    number: 4,
    icon: Coins,
    title: "Poin Dihitung",
    description: "Poin akan langsung ditambahkan ke akunmu.",
  },
  {
    number: 5,
    icon: History,
    title: "Riwayat Tersimpan",
    description: "Semua transaksi tersimpan rapi di akun untuk dipantau kapan saja.",
  },
  {
    number: 6,
    icon: Gift,
    title: "Tukar Poin",
    description: "Kumpulkan poin dan tukarkan dengan berbagai hadiah menarik.",
  },
]

export function HowItWorksSection() {
  return (
    <section id="cara-kerja" className="relative py-16 md:py-24 bg-background overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-secondary/30 to-transparent rounded-full blur-3xl" />
      
      <div className="relative container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-4">
            <Leaf className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-muted-foreground">Mudah & Cepat</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Daur Ulang Jadi Mudah, Ikuti{" "}
            <span className="gradient-text">6 Langkah Ini</span>
            <span className="inline-block ml-2">
              <Leaf className="w-6 h-6 md:w-8 md:h-8 text-accent inline" />
            </span>
          </h2>
          <p className="text-muted-foreground text-base md:text-lg">
            Proses daur ulang yang simpel dan rewarding untuk semua mahasiswa UPN Veteran Jawa Timur.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6 mb-10">
          {steps.map((step, index) => (
            <div key={step.number} className="relative group">
              {/* Connector line (hidden on mobile and last item per row) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-1/2 w-full h-0.5 bg-gradient-to-r from-primary/30 to-primary/10 z-0" />
              )}
              
              <div className="relative z-10 flex flex-col items-center text-center">
                {/* Number badge */}
                <div className="relative mb-4">
                  <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/25 group-hover:shadow-primary/40 group-hover:scale-105 transition-all duration-300">
                    <span className="text-lg md:text-xl font-bold text-primary-foreground">{step.number}</span>
                  </div>
                  {/* Icon overlay */}
                  <div className="absolute -bottom-2 -right-2 w-8 h-8 md:w-9 md:h-9 rounded-xl bg-card border-2 border-border flex items-center justify-center shadow-md">
                    <step.icon className="w-4 h-4 md:w-5 md:h-5 text-primary" />
                  </div>
                </div>
                
                {/* Content card */}
                <div className="bg-card rounded-2xl p-4 border border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 w-full">
                  <h3 className="font-semibold text-foreground mb-2 text-sm md:text-base">{step.title}</h3>
                  <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button
            variant="outline"
            size="lg"
            className="border-2 border-primary/30 hover:border-primary hover:bg-primary/5 text-foreground rounded-2xl group"
          >
            Pelajari Selengkapnya
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  )
}
