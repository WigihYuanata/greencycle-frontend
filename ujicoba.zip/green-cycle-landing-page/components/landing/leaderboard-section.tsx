"use client"

import { Trophy, ChevronRight, Star, Leaf, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"

const leaderboardData = [
  { rank: 1, name: "Wigih Yuanata", faculty: "Fak. Ilmu Komputer", points: 5620, badge: "🥇" },
  { rank: 2, name: "Ahmad ferizal Wildan S.", faculty: "Fak. Teknik", points: 4830, badge: "🥈" },
  { rank: 3, name: "Arif", faculty: "Fak. Ilmu Sosial & Politik", points: 4210, badge: "🥉" },
  { rank: 4, name: "Diana", faculty: "Fak. Pertanian", points: 3980, badge: "4" },
  { rank: 5, name: "Zaki", faculty: "Fak. Teknik", points: 3450, badge: "5" },
]

export function LeaderboardSection() {
  return (
    <section className="py-16 md:py-24 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Leaderboard */}
          <div className="bg-background rounded-3xl p-6 md:p-8 border border-border/50 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-foreground">Top Kontributor Minggu Ini</h3>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 text-sm">
                Lihat Semua
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>

            <div className="space-y-3">
              {leaderboardData.map((user, index) => (
                <div
                  key={user.rank}
                  className={`flex items-center justify-between p-3 md:p-4 rounded-2xl transition-all duration-200 ${
                    index === 0 
                      ? "bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20" 
                      : "bg-secondary/50 hover:bg-secondary"
                  }`}
                >
                  <div className="flex items-center gap-3 md:gap-4">
                    {/* Rank badge */}
                    <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center text-sm md:text-base font-bold ${
                      index === 0 ? "bg-primary text-primary-foreground" :
                      index === 1 ? "bg-muted-foreground/30 text-foreground" :
                      index === 2 ? "bg-accent/30 text-accent-foreground" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      {user.badge}
                    </div>
                    
                    {/* User info */}
                    <div>
                      <p className="font-semibold text-foreground text-sm md:text-base">{user.name}</p>
                      <p className="text-xs md:text-sm text-muted-foreground">{user.faculty}</p>
                    </div>
                  </div>
                  
                  {/* Points */}
                  <div className="text-right">
                    <p className="font-bold text-primary text-base md:text-lg">{user.points.toLocaleString()}</p>
                    <p className="text-xs text-accent font-medium">+ Poin</p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-accent/5 rounded-2xl border border-primary/10">
              <p className="text-sm text-muted-foreground mb-3">
                <strong className="text-foreground">Posisimu selanjutnya?</strong>
                <br />
                Mulai daur ulang sekarang dan masuk ke Top Kontributor!
              </p>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl">
                Mulai Sekarang
                <Star className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          {/* Dashboard Preview */}
          <div className="bg-background rounded-3xl p-6 md:p-8 border border-border/50 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                <Leaf className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-bold text-foreground">Intip Dashboard-mu</h3>
                <p className="text-sm text-muted-foreground">Semua aktivitasmu dalam satu tempat.</p>
              </div>
            </div>

            {/* Mock Dashboard */}
            <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-4 md:p-6 text-primary-foreground mb-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm opacity-80 mb-1">Halo, Dimas Maulana 👋</p>
                  <div className="flex items-center gap-2">
                    <p className="text-xs opacity-70">Saldo Poin Kamu</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs opacity-70 mb-1">Riwayat Terakhir</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-end gap-2 text-xs">
                      <span className="opacity-80">Botol Plastik Sedang</span>
                      <span className="font-medium">+20 Poin</span>
                    </div>
                    <p className="text-[10px] opacity-60">26 Apr 2025 - 10:34</p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-4xl md:text-5xl font-bold">2.450</span>
                <span className="text-lg">Poin</span>
              </div>
              
              <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-primary-foreground border-0 rounded-xl">
                Lihat Detail
              </Button>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-secondary/50 rounded-xl p-3 text-center">
                <p className="text-lg md:text-xl font-bold text-foreground">128</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">3.250+</p>
              </div>
              <div className="bg-secondary/50 rounded-xl p-3 text-center">
                <p className="text-lg md:text-xl font-bold text-foreground">7</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">Hari Beruntun</p>
              </div>
              <div className="bg-secondary/50 rounded-xl p-3 text-center">
                <p className="text-lg md:text-xl font-bold text-foreground">Top 12%</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">di Kampus</p>
              </div>
            </div>

            {/* Mini chart and impact */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-secondary/30 rounded-xl p-4">
                <p className="text-xs text-muted-foreground mb-2">Grafik Kontribusi</p>
                <div className="flex items-end gap-1 h-12">
                  {[40, 60, 35, 80, 50, 70, 55].map((height, i) => (
                    <div 
                      key={i} 
                      className="flex-1 bg-primary/40 rounded-sm hover:bg-primary/60 transition-colors"
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                  <span>Sen</span>
                  <span>Min</span>
                </div>
              </div>
              
              <div className="bg-secondary/30 rounded-xl p-4">
                <p className="text-xs text-muted-foreground mb-2">Dampakmu</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">CO₂</span>
                    <span className="text-sm font-semibold text-foreground">12,4 kg</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground">Emisi CO₂ Berhasil Dikurangi</p>
                  <div className="flex items-center gap-1 text-accent">
                    <TrendingUp className="w-3 h-3" />
                    <span className="text-xs font-medium">5%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
