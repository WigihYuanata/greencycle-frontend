"use client"

import { Leaf, Mail, Phone, MapPin, Instagram, Twitter, Youtube, Linkedin, Heart } from "lucide-react"

const footerLinks = {
  navigasi: [
    { label: "Beranda", href: "#beranda" },
    { label: "Tentang Kami", href: "#tentang" },
    { label: "Cara Kerja", href: "#cara-kerja" },
    { label: "Dampak", href: "#dampak" },
    { label: "Poin & Reward", href: "#reward" },
    { label: "FAQ", href: "#faq" },
  ],
  program: [
    { label: "Smart BIN", href: "#" },
    { label: "Riset & Inovasi", href: "#" },
    { label: "Edukasi Lingkungan", href: "#" },
    { label: "Komunitas", href: "#" },
    { label: "Kolaborasi", href: "#" },
  ],
  bantuan: [
    { label: "Pusat Bantuan", href: "#" },
    { label: "Kebijakan Privasi", href: "#" },
    { label: "Syarat & Ketentuan", href: "#" },
    { label: "Kontak Kami", href: "#" },
  ],
}

const socialLinks = [
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Youtube, href: "#", label: "YouTube" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
]

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      {/* Main footer */}
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 md:gap-12">
          {/* Brand column */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1 mb-4 lg:mb-0">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Leaf className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <span className="text-lg font-bold text-background">GreenCycle</span>
                <p className="text-[10px] text-background/60">Teaching Industry Project UPN Veteran Jawa Timur</p>
              </div>
            </div>
            <p className="text-sm text-background/70 mb-4 max-w-xs">
              Project Dosen UPN &ldquo;Veteran&rdquo; Jawa Timur untuk menciptakan kampus yang lebih hijau berkelanjutan melalui aksi nyata dan inovasi.
            </p>
            
            {/* Social links */}
            <div className="flex items-center gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-9 h-9 rounded-full bg-background/10 hover:bg-background/20 flex items-center justify-center transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-4 h-4 text-background/80" />
                </a>
              ))}
            </div>
          </div>
          
          {/* Navigasi */}
          <div>
            <h4 className="font-semibold text-background mb-4 text-sm">Navigasi</h4>
            <ul className="space-y-2">
              {footerLinks.navigasi.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href} 
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Program */}
          <div>
            <h4 className="font-semibold text-background mb-4 text-sm">Program</h4>
            <ul className="space-y-2">
              {footerLinks.program.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href} 
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Bantuan */}
          <div>
            <h4 className="font-semibold text-background mb-4 text-sm">Bantuan</h4>
            <ul className="space-y-2">
              {footerLinks.bantuan.map((link) => (
                <li key={link.label}>
                  <a 
                    href={link.href} 
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="font-semibold text-background mb-4 text-sm">Hubungi Kami</h4>
            <div className="space-y-3">
              <p className="text-xs text-background/60 font-medium">
                GreenCycle UPN &ldquo;Veteran&rdquo; Jawa Timur
              </p>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-background/60 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-background/60">
                  Kampus UPN Veteran Jawa Timur<br />
                  Jl. Rungkut Madya, Surabaya 60294
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-background/60" />
                <a href="mailto:greencycle.upnvjatim@gmail.com" className="text-xs text-background/60 hover:text-background transition-colors">
                  greencycle.upnvjatim@gmail.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-background/60" />
                <a href="tel:+62318706561" className="text-xs text-background/60 hover:text-background transition-colors">
                  (031) 8706 561
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom bar */}
      <div className="border-t border-background/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-background/50 text-center md:text-left">
              © 2026 GreenCycle. All rights reserved.
            </p>
            <p className="text-xs text-background/50 flex items-center gap-1">
              Dibuat dengan <Heart className="w-3 h-3 text-red-400 fill-red-400" /> untuk bumi yang lebih baik.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
