"use client"

import { Recycle, Users, Gift, Building2, TreePine } from "lucide-react"

const stats = [
  {
    icon: Recycle,
    value: "3.250+",
    label: "Botol Telah Didaur Ulang",
    description: "Bersama kita kurangi sampah plastik.",
  },
  {
    icon: Users,
    value: "2.350+",
    label: "Kontributor Aktif",
    description: "Mahasiswa hebat yang peduli lingkungan.",
  },
  {
    icon: Gift,
    value: "845.600+",
    label: "Poin Telah Ditukarkan",
    description: "Poinmu, manfaat untuk banyak hal.",
  },
  {
    icon: Building2,
    value: "7",
    label: "Fakultas Terlibat",
    description: "Gerakan besar dari seluruh fakultas.",
  },
  {
    icon: TreePine,
    value: "100+",
    label: "Pohon Terselamatkan",
    description: "Berkat langkah kecil kita bersama.",
  },
]

export function StatsSection() {
  return (
    <section className="relative py-8 md:py-12 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="group relative bg-gradient-to-br from-secondary/50 to-card rounded-2xl md:rounded-3xl p-4 md:p-6 border border-border/50 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Icon */}
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-primary/10 flex items-center justify-center mb-3 md:mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300">
                <stat.icon className="w-5 h-5 md:w-6 md:h-6 text-primary" />
              </div>
              
              {/* Value */}
              <p className="text-xl md:text-2xl lg:text-3xl font-bold text-foreground mb-1">
                {stat.value}
              </p>
              
              {/* Label */}
              <p className="text-sm md:text-base font-medium text-primary mb-1">
                {stat.label}
              </p>
              
              {/* Description */}
              <p className="text-xs md:text-sm text-muted-foreground hidden md:block">
                {stat.description}
              </p>
              
              {/* Decorative corner */}
              <div className="absolute top-2 right-2 w-8 h-8 rounded-full bg-accent/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
