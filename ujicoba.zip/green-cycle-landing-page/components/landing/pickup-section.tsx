"use client"

import { useState } from "react"
import { Truck, Calendar, MapPin, Phone, Check, Leaf, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface PickupSectionProps {
  onLoginRequired: () => void
}

export function PickupSection({ onLoginRequired }: PickupSectionProps) {
  const [isLoggedIn] = useState(false) // In real app, this would come from auth context
  const [hasPendingOrder] = useState(false) // In real app, this would come from API
  const [formData, setFormData] = useState({
    pickup_address: "",
    contact_number: "",
    scheduled_day: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!isLoggedIn) {
      onLoginRequired()
      return
    }
    // In real app, this would call the pickup API
    console.log("Pickup order submitted:", formData)
  }

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            {/* Info side */}
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-4">
                <Truck className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium text-muted-foreground">Layanan Jemput</span>
              </div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
                Malas ke Mesin?
                <br />
                <span className="gradient-text">Kita Jemput!</span>
              </h2>
              <p className="text-muted-foreground text-base md:text-lg mb-8">
                Tidak sempat ke mesin Smart BIN? Tenang, kamu bisa request penjemputan botol langsung ke lokasi kamu!
              </p>

              {/* Benefits */}
              <div className="space-y-4">
                {[
                  { title: "Gratis", desc: "Layanan penjemputan tanpa biaya tambahan" },
                  { title: "Jadwal Fleksibel", desc: "Pilih hari Sabtu atau Minggu" },
                  { title: "Poin Sama", desc: "Tetap dapat poin penuh untuk setiap botol" },
                ].map((benefit) => (
                  <div key={benefit.title} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check className="w-4 h-4 text-accent" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{benefit.title}</p>
                      <p className="text-sm text-muted-foreground">{benefit.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Form side */}
            <div className="bg-card rounded-3xl p-6 md:p-8 border border-border/50 shadow-sm">
              {hasPendingOrder ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                    <Calendar className="w-8 h-8 text-accent" />
                  </div>
                  <h3 className="font-semibold text-foreground text-lg mb-2">
                    Pesanan Aktif
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Kamu sudah memiliki pesanan penjemputan yang sedang diproses.
                  </p>
                  <div className="bg-secondary/50 rounded-xl p-4 text-left">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <Calendar className="w-4 h-4" />
                      <span>Dijadwalkan: <strong className="text-foreground">Sabtu</strong></span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <AlertCircle className="w-4 h-4" />
                      <span>Status: <strong className="text-accent">Pending</strong></span>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Truck className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Request Penjemputan</h3>
                      <p className="text-sm text-muted-foreground">Isi form di bawah ini</p>
                    </div>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="address" className="text-foreground text-sm">Alamat Penjemputan</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="address"
                          placeholder="Contoh: Gedung A, Lt. 2, Ruang 201"
                          value={formData.pickup_address}
                          onChange={(e) => setFormData({ ...formData, pickup_address: e.target.value })}
                          className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contact" className="text-foreground text-sm">Nomor Kontak</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="contact"
                          type="tel"
                          placeholder="08xxxxxxxxxx"
                          value={formData.contact_number}
                          onChange={(e) => setFormData({ ...formData, contact_number: e.target.value })}
                          className="pl-10 rounded-xl border-border/50 bg-secondary/30 focus:bg-card"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="day" className="text-foreground text-sm">Jadwal Penjemputan</Label>
                      <Select
                        value={formData.scheduled_day}
                        onValueChange={(value) => setFormData({ ...formData, scheduled_day: value })}
                      >
                        <SelectTrigger className="w-full rounded-xl border-border/50 bg-secondary/30">
                          <Calendar className="w-4 h-4 text-muted-foreground mr-2" />
                          <SelectValue placeholder="Pilih Hari" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Sabtu">Sabtu</SelectItem>
                          <SelectItem value="Minggu">Minggu</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-[10px] text-muted-foreground">
                        * Layanan penjemputan tersedia setiap Sabtu dan Minggu
                      </p>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl py-6 text-base shadow-lg shadow-primary/25 mt-2"
                    >
                      <Truck className="w-5 h-5 mr-2" />
                      Request Penjemputan
                    </Button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
