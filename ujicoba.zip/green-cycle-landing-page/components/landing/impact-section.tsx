"use client"

import { Recycle, Droplets, Cloud, Zap, TreePine, Building2, ArrowRight, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"

const impactStats = [
  {
    icon: Recycle,
    value: "3.250+",
    label: "Botol Didaur Ulang",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Droplets,
    value: "6.500 L",
    label: "Air Terselamatkan",
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    icon: Cloud,
    value: "215 kg",
    label: "Emisi CO₂ Dikurangi",
    color: "text-slate-600",
    bgColor: "bg-slate-100",
  },
  {
    icon: Zap,
    value: "1.200 kWh",
    label: "Energi Dihemat",
    color: "text-amber-600",
    bgColor: "bg-amber-100",
  },
  {
    icon: TreePine,
    value: "100+",
    label: "Pohon Terselamatkan",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Building2,
    value: "7",
    label: "Fakultas Terlibat",
    color: "text-violet-600",
    bgColor: "bg-violet-100",
  },
]

export function ImpactSection() {
  return (
    <section id="dampak" className="relative py-16 md:py-24 bg-background overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-3xl -translate-y-1/2 -translate-x-1/2" />
      <div className="absolute top-1/2 right-0 w-[300px] h-[300px] bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      
      <div className="relative container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-4">
            <Leaf className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-muted-foreground">Dampak Nyata</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Dampak Nyata untuk Kampus & Bumi
            <span className="inline-block ml-2">
              <Leaf className="w-6 h-6 md:w-8 md:h-8 text-accent inline" />
            </span>
          </h2>
          <p className="text-muted-foreground text-base md:text-lg">
            Setiap botol yang kamu daur ulang berkontribusi pada perubahan nyata untuk lingkungan kita.
          </p>
        </div>

        {/* Impact Cards */}
        <div className="bg-card rounded-3xl border border-border/50 p-6 md:p-8 shadow-sm">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
            {impactStats.map((stat, index) => (
              <div
                key={stat.label}
                className="group text-center p-4 rounded-2xl hover:bg-secondary/50 transition-all duration-300"
              >
                <div className={`w-12 h-12 md:w-14 md:h-14 rounded-2xl ${stat.bgColor} flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon className={`w-6 h-6 md:w-7 md:h-7 ${stat.color}`} />
                </div>
                <p className="text-xl md:text-2xl font-bold text-foreground mb-1">{stat.value}</p>
                <p className="text-xs md:text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-8">
          <Button
            variant="outline"
            size="lg"
            className="border-2 border-primary/30 hover:border-primary hover:bg-primary/5 text-foreground rounded-2xl group"
          >
            Lihat Selengkapnya di Halaman Dampak
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  )
}
