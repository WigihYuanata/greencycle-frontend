"use client"

import { useRef } from "react"
import { Gift, Coffee, ShoppingBag, Headphones, Shirt, ChevronLeft, ChevronRight, Leaf, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const rewards = [
  {
    id: 1,
    icon: Coffee,
    name: "Es Kopi Selasar",
    description: "Voucher es kopi favorit mahasiswa",
    pointCost: 150,
    cafeName: "Selasar Caffe",
    image: "☕",
  },
  {
    id: 2,
    icon: Coffee,
    name: "Matcha Latte",
    description: "Minuman matcha creamy spesial Selasar",
    pointCost: 220,
    cafeName: "Selasar Caffe",
    image: "🍵",
  },
  {
    id: 3,
    icon: Coffee,
    name: "Chocolate Ice",
    description: "Coklat dingin manis untuk teman nongkrong",
    pointCost: 250,
    cafeName: "Selasar Caffe",
    image: "🍫",
  },
  {
    id: 4,
    icon: Coffee,
    name: "Croffle + Coffee",
    description: "Paket croffle dan kopi hemat mahasiswa",
    pointCost: 400,
    cafeName: "Selasar Caffe",
    image: "🧇",
  },
  {
    id: 5,
    icon: Coffee,
    name: "Americano Dingin",
    description: "Americano segar untuk boost produktivitas",
    pointCost: 180,
    cafeName: "Selasar Caffe",
    image: "🥤",
  },
  {
    id: 6,
    icon: Gift,
    name: "Voucher Nongkrong",
    description: "Voucher diskon spesial GreenCycle",
    pointCost: 500,
    cafeName: "Selasar Caffe",
    image: "🎟️",
  },
]

interface RewardsSectionProps {
  onRedeemClick: () => void
}

export function RewardsSection({ onRedeemClick }: RewardsSectionProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = direction === "left" ? -280 : 280
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" })
    }
  }

  return (
    <section id="reward" className="relative py-16 md:py-24 bg-card overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2" />
      
      <div className="relative container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8 md:mb-12">
          <div className="mb-6 md:mb-0">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-4">
              <Gift className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-muted-foreground">Reward Menarik</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-2 text-balance">
              Tukar Poin, Dapatkan Reward Menarik
              <span className="inline-block ml-2">
                <Leaf className="w-6 h-6 md:w-8 md:h-8 text-accent inline" />
              </span>
            </h2>
            <p className="text-muted-foreground text-base md:text-lg max-w-xl">
              Kumpulkan poin dari setiap botol yang kamu daur ulang dan tukarkan dengan berbagai hadiah eksklusif.
            </p>
          </div>
          
          {/* Desktop scroll buttons */}
          <div className="hidden md:flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll("left")}
              className="rounded-full border-2"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll("right")}
              className="rounded-full border-2"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Rewards Carousel */}
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar snap-x snap-mandatory -mx-4 px-4"
        >
          {rewards.map((reward) => (
            <div
              key={reward.id}
              className="flex-shrink-0 w-[220px] md:w-[260px] snap-start group"
            >
              <div className="bg-background rounded-2xl md:rounded-3xl p-4 md:p-5 border border-border/50 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 h-full flex flex-col">
                {/* Image placeholder */}
                <div className="aspect-square rounded-xl md:rounded-2xl bg-gradient-to-br from-secondary to-muted mb-4 flex items-center justify-center group-hover:scale-[1.02] transition-transform">
                  <span className="text-5xl md:text-6xl">{reward.image}</span>
                </div>
                
                {/* Content */}
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-sm md:text-base mb-1">{reward.name}</h3>
                  <p className="text-xs md:text-sm text-muted-foreground mb-3 line-clamp-2">{reward.description}</p>
                </div>
                
                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-border/50">
                  <div>
                    <p className="text-lg md:text-xl font-bold text-primary">{reward.pointCost}</p>
                    <p className="text-[10px] md:text-xs text-muted-foreground">Poin</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={onRedeemClick}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl text-xs px-3"
                  >
                    Tukar
                  </Button>
                </div>
              </div>
            </div>
          ))}
          
          {/* See all card */}
          <div className="flex-shrink-0 w-[160px] md:w-[200px] snap-start">
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl md:rounded-3xl p-4 md:p-5 border border-primary/20 h-full flex flex-col items-center justify-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-3">
                <ArrowRight className="w-6 h-6 text-primary" />
              </div>
              <p className="font-semibold text-foreground text-sm mb-1">Lihat Semua</p>
              <p className="text-xs text-muted-foreground">Reward</p>
            </div>
          </div>
        </div>

        {/* Mobile scroll indicator */}
        <div className="flex justify-center gap-1 mt-4 md:hidden">
          {[...Array(4)].map((_, i) => (
            <div key={i} className={`w-2 h-2 rounded-full ${i === 0 ? "bg-primary" : "bg-border"}`} />
          ))}
        </div>
      </div>
    </section>
  )
}
