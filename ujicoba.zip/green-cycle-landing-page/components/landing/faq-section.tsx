"use client"

import { HelpCircle, Leaf } from "lucide-react"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    question: "Bagaimana cara mendaftar di GreenCycle?",
    answer: "Kamu bisa mendaftar dengan mengklik tombol 'Daftar Sekarang' di halaman ini. Cukup masukkan NPM, nama lengkap, fakultas, email student (@student.upnjatim.ac.id), dan buat PIN untuk akunmu. Setelah registrasi, kamu bisa langsung mulai mengumpulkan poin!",
  },
  {
    question: "Botol plastik apa saja yang bisa didaur ulang?",
    answer: "GreenCycle menerima semua jenis botol plastik PET (biasanya bertanda segitiga dengan angka 1). Ini termasuk botol air mineral, minuman bersoda, jus, dan sebagainya. Botol dibagi menjadi 3 ukuran: kecil (<600ml), sedang (600ml-1L), dan besar (>1L) dengan poin berbeda.",
  },
  {
    question: "Berapa poin yang didapat dari setiap botol?",
    answer: "Poin dihitung berdasarkan ukuran botol: Botol kecil (<600ml) = 10 poin, Botol sedang (600ml-1L) = 20 poin, dan Botol besar (>1L) = 30 poin. Semakin besar botol yang kamu daur ulang, semakin banyak poin yang didapat!",
  },
  {
    question: "Bagaimana cara menukar poin menjadi reward?",
    answer: "Setelah mengumpulkan poin yang cukup, kamu bisa masuk ke dashboard dan pilih menu 'Tukar Poin'. Pilih reward yang kamu inginkan, dan sistem akan menghasilkan voucher dengan QR code unik. Tunjukkan QR code ini di merchant partner untuk menukarkan reward.",
  },
  {
    question: "Apakah kartu mahasiswa wajib untuk menggunakan Smart BIN?",
    answer: "Ya, kamu perlu mendaftarkan kartu mahasiswa (RFID) ke akun GreenCycle untuk menggunakan mesin Smart BIN. Caranya: daftar akun terlebih dahulu, lalu tautkan kartu mahasiswamu di mesin Smart BIN dengan bantuan petunjuk yang tersedia.",
  },
  {
    question: "Bagaimana jika saya lupa PIN akun GreenCycle?",
    answer: "Jangan khawatir! Klik 'Lupa PIN' di halaman login, masukkan NPM-mu, dan kode verifikasi akan dikirim ke email student yang terdaftar. Gunakan kode tersebut untuk membuat PIN baru.",
  },
  {
    question: "Bisakah saya request penjemputan botol?",
    answer: "Bisa! Gunakan fitur 'Request Penjemputan' di dashboard. Isi alamat, nomor kontak, dan pilih jadwal (Sabtu atau Minggu). Tim kami akan menjemput botol-botolmu. Catatan: kamu hanya bisa memiliki 1 pesanan penjemputan aktif dalam satu waktu.",
  },
  {
    question: "Di mana lokasi mesin Smart BIN?",
    answer: "Mesin Smart BIN tersebar di berbagai lokasi strategis di kampus UPN Veteran Jawa Timur. Lokasi terupdate bisa dilihat di peta kampus atau tanyakan di pusat informasi. Kami terus menambah lokasi untuk kemudahan akses.",
  },
]

export function FAQSection() {
  return (
    <section id="faq" className="py-16 md:py-24 bg-card">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-10 md:mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border/50 mb-4">
              <HelpCircle className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-muted-foreground">FAQ</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
              Pertanyaan yang Sering Diajukan
              <span className="inline-block ml-2">
                <Leaf className="w-6 h-6 md:w-8 md:h-8 text-accent inline" />
              </span>
            </h2>
            <p className="text-muted-foreground text-base md:text-lg">
              Temukan jawaban untuk pertanyaan umum tentang GreenCycle.
            </p>
          </div>

          {/* FAQ Accordion */}
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-background rounded-2xl border border-border/50 px-5 md:px-6 data-[state=open]:border-primary/30 data-[state=open]:shadow-sm transition-all"
              >
                <AccordionTrigger className="hover:no-underline py-4 md:py-5 text-left gap-4">
                  <span className="font-medium text-foreground text-sm md:text-base">
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm md:text-base pb-4 md:pb-5 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          {/* Contact CTA */}
          <div className="mt-10 text-center">
            <p className="text-muted-foreground text-sm mb-2">
              Masih punya pertanyaan?
            </p>
            <a
              href="mailto:greencycle@upnjatim.ac.id"
              className="text-primary font-medium hover:underline"
            >
              Hubungi Tim GreenCycle
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
