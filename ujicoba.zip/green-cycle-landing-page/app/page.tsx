"use client"

import { useState } from "react"
import { Header } from "@/components/landing/header"
import { HeroSection } from "@/components/landing/hero-section"
import { StatsSection } from "@/components/landing/stats-section"
import { HowItWorksSection } from "@/components/landing/how-it-works-section"
import { LeaderboardSection } from "@/components/landing/leaderboard-section"
import { ImpactSection } from "@/components/landing/impact-section"
import { RewardsSection } from "@/components/landing/rewards-section"
import { PickupSection } from "@/components/landing/pickup-section"
import { FAQSection } from "@/components/landing/faq-section"
import { CTASection } from "@/components/landing/cta-section"
import { Footer } from "@/components/landing/footer"
import { AuthModals } from "@/components/landing/auth-modals"

type AuthView = "login" | "register" | "forgot" | "reset"

export default function GreenCycleLanding() {
  const [isAuthOpen, setIsAuthOpen] = useState(false)
  const [authView, setAuthView] = useState<AuthView>("login")

  const openAuth = (view: AuthView) => {
    setAuthView(view)
    setIsAuthOpen(true)
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onLoginClick={() => openAuth("login")}
        onRegisterClick={() => openAuth("register")}
      />

      {/* Hero Section */}
      <HeroSection 
  onStartClick={() => openAuth("register")}
  onHowItWorksClick={() => scrollToSection("cara-kerja")}
/>

<section className="py-16 bg-background">
  <div className="container mx-auto px-4 max-w-5xl">
    
    <div className="text-center mb-10">
      <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
        Tentang GreenCycle
      </h2>

      <p className="text-muted-foreground text-lg leading-relaxed">
        GreenCycle merupakan inisiatif pengelolaan limbah botol plastik
        di lingkungan UPN Veteran Jawa Timur yang bertujuan meningkatkan
        kesadaran mahasiswa terhadap pentingnya daur ulang dan sustainability.
      </p>
    </div>

    <div className="grid md:grid-cols-3 gap-6">
      
      <div className="rounded-2xl border border-border p-6 bg-card">
        <h3 className="font-semibold text-xl mb-2">
          Fokus Lingkungan
        </h3>

        <p className="text-muted-foreground">
          Mengurangi limbah botol plastik di area kampus melalui sistem
          pengumpulan dan penukaran poin.
        </p>
      </div>

      <div className="rounded-2xl border border-border p-6 bg-card">
        <h3 className="font-semibold text-xl mb-2">
          Edukasi Mahasiswa
        </h3>

        <p className="text-muted-foreground">
          Mendorong mahasiswa untuk lebih peduli terhadap sustainability
          dan pengelolaan limbah anorganik.
        </p>
      </div>

      <div className="rounded-2xl border border-border p-6 bg-card">
        <h3 className="font-semibold text-xl mb-2">
          Kolaborasi Kampus
        </h3>

        <p className="text-muted-foreground">
          Mendukung Teaching Industry dan pengembangan inovasi lingkungan
          di UPN Veteran Jawa Timur.
        </p>
      </div>

    </div>
  </div>
</section>

      {/* Stats Section */}
      <StatsSection />

      {/* How It Works Section */}
      <HowItWorksSection />

      {/* Leaderboard & Dashboard Preview Section */}
      <LeaderboardSection />

      {/* Environmental Impact Section */}
      <ImpactSection />

      {/* Rewards Marketplace Section */}
      <RewardsSection 
        onRedeemClick={() => openAuth("login")}
      />

      {/* Pickup Order Section */}
      <PickupSection 
        onLoginRequired={() => openAuth("login")}
      />

      {/* FAQ Section */}
      <FAQSection />

      {/* Final CTA Section */}
      <CTASection 
        onStartClick={() => openAuth("register")}
        onRewardsClick={() => scrollToSection("reward")}
      />

      {/* Footer */}
      <Footer />

      {/* Auth Modals */}
      <AuthModals 
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialView={authView}
      />
    </main>
  )
}
