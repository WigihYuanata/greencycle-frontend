import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Plus_Jakarta_Sans } from 'next/font/google'

import './globals.css'

const geist = Geist({ 
  subsets: ["latin"],
  variable: "--font-geist",
});

const geistMono = Geist_Mono({ 
  subsets: ["latin"],
  variable: "--font-geist-mono",
});

const plusJakarta = Plus_Jakarta_Sans({ 
  subsets: ["latin"],
  variable: "--font-jakarta",
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: 'GreenCycle | Ubah Botol Plastik Jadi Langkah Nyata untuk Bumi',
  description: 'GreenCycle mengajak seluruh mahasiswa UPN Veteran Jawa Timur untuk bersama-sama daur ulang, kumpulkan poin, dan ciptakan dampak besar bagi lingkungan kampus.',
  keywords: ['recycling', 'eco', 'green', 'campus', 'UPN', 'plastic', 'bottles', 'rewards', 'sustainability'],
  authors: [{ name: 'GreenCycle Team - Teaching Industry UPNVJT' }],
  openGraph: {
    title: 'GreenCycle | Sistem Pengumpulan Botol Plastik untuk Mendukung Pengelolaan Limbah Kampus',
    description: 'Turn plastic bottles into real environmental impact and meaningful rewards.',
    type: 'website',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#1a5d3a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="id" className="bg-background">
      <body className={`${geist.variable} ${geistMono.variable} ${plusJakarta.variable} font-sans antialiased`}>
        {children}
        
      </body>
    </html>
  )
}
